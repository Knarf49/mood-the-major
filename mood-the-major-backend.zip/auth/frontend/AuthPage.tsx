import { useActionState, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

const API_URL = "http://localhost:8000";

// ---------- Types ----------
interface FormState {
  error: string | null;
  success: string | null;
}

const initialState: FormState = { error: null, success: null };

// ---------- Login ----------
async function loginAction(_prevState: FormState, formData: FormData): Promise<FormState> {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  try {
    const res = await fetch(`${API_URL}/login`, {
      method: "POST",
      credentials: "include", // required so the browser stores the httpOnly refresh cookie
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      return { error: data.error || "Login failed", success: null };
    }

    // TODO: store data.accessToken + data.user in your Zustand auth store here
    return { error: null, success: "Logged in successfully" };
  } catch {
    return { error: "Could not reach the server. Is the backend running?", success: null };
  }
}

// ---------- Signup ----------
interface SignupFormState extends FormState {
  email?: string;
}

const signupInitialState: SignupFormState = { error: null, success: null };

async function signupAction(_prevState: SignupFormState, formData: FormData): Promise<SignupFormState> {
  const username = formData.get("username") as string;
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  try {
    const res = await fetch(`${API_URL}/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, email, password }),
    });

    const data = await res.json();

    if (!res.ok) {
      return { error: data.error?.formErrors?.[0] || data.error || "Signup failed", success: null };
    }

    return { error: null, success: "Account created", email };
  } catch {
    return { error: "Could not reach the server. Is the backend running?", success: null };
  }
}

// ---------- Login form ----------
function LoginForm() {
  const [state, formAction, isPending] = useActionState(loginAction, initialState);

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="login-email">Email</Label>
        <Input id="login-email" name="email" type="email" placeholder="you@example.com" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="login-password">Password</Label>
        <Input id="login-password" name="password" type="password" placeholder="••••••••" required />
      </div>

      {state.error && <p className="text-sm text-red-500">{state.error}</p>}
      {state.success && <p className="text-sm text-emerald-600">{state.success}</p>}

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? "Logging in..." : "Log in"}
      </Button>
    </form>
  );
}

// ---------- Signup form ----------
function SignupForm() {
  const [state, formAction, isPending] = useActionState(signupAction, signupInitialState);
  const navigate = useNavigate();

  useEffect(() => {
    if (state.success && state.email) {
      navigate(`/verify-email?email=${encodeURIComponent(state.email)}`);
    }
  }, [state.success, state.email, navigate]);

  return (
    <form action={formAction} className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="signup-username">Username</Label>
        <Input id="signup-username" name="username" type="text" placeholder="janedoe" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="signup-email">Email</Label>
        <Input id="signup-email" name="email" type="email" placeholder="you@example.com" required />
      </div>
      <div className="space-y-2">
        <Label htmlFor="signup-password">Password</Label>
        <Input id="signup-password" name="password" type="password" placeholder="At least 8 characters" required />
      </div>

      {state.error && <p className="text-sm text-red-500">{state.error}</p>}
      {state.success && <p className="text-sm text-emerald-600">{state.success}</p>}

      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? "Creating account..." : "Sign up"}
      </Button>
    </form>
  );
}

// ---------- Page: switches between the two ----------
export default function AuthPage() {
  const [mode, setMode] = useState<"login" | "signup">("login");
  const isLogin = mode === "login";

  return (
    <div className="min-h-screen flex items-center justify-center bg-neutral-50 px-4">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>{isLogin ? "Log in" : "Create an account"}</CardTitle>
          <CardDescription>
            {isLogin
              ? "Welcome back to mood-the-major."
              : "Join the board and start sharing sticky notes."}
          </CardDescription>
        </CardHeader>

        <CardContent>{isLogin ? <LoginForm /> : <SignupForm />}</CardContent>

        <CardFooter className="justify-center">
          <button
            type="button"
            onClick={() => setMode(isLogin ? "signup" : "login")}
            className="text-sm text-neutral-500"
          >
            {isLogin ? (
              <>Don't have an account? <span className="text-neutral-900 font-medium underline underline-offset-4">Sign up</span></>
            ) : (
              <>Already have an account? <span className="text-neutral-900 font-medium underline underline-offset-4">Log in</span></>
            )}
          </button>
        </CardFooter>
      </Card>
    </div>
  );
}
